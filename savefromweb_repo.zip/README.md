# SaveFromWeb

Full-stack social media downloader SaaS.

## Deploy
- Frontend: Vercel
- Backend: Railway
