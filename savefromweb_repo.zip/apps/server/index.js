import express from "express";
import cors from "cors";
import ytdlp from "yt-dlp-exec";

const app = express();
app.use(cors());
app.use(express.json());

app.post("/api/download", async (req, res) => {
  try {
    const { url } = req.body;
    const info = await ytdlp(url, { dumpSingleJson: true });

    res.json({
      title: info.title,
      thumbnail: info.thumbnail,
      formats: info.formats
        .filter(f => f.ext === "mp4")
        .map(f => ({ quality: f.format_note, url: f.url }))
    });
  } catch {
    res.status(500).json({ error: "Failed" });
  }
});

app.listen(5000, () => console.log("Server running"));
