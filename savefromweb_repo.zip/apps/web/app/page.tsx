export default function Home() {
  return (
    <main>
      <h1>SaveFromWeb</h1>
      <p>Download videos instantly.</p>
    </main>
  );
}
